﻿using UnityEngine;
using UnityEngine.SceneManagement;
using System.Collections;


public static class Scenemov{
    public static void toMain(){
        SceneManager.LoadScene("Main");
    }
    public static void toHtP(){
        SceneManager.LoadScene("Howtoplay");
    }
    public static void toSelect(){
        SceneManager.LoadScene("Select");
    }
    public static void toCredit(){
        SceneManager.LoadScene("Credit");
    }
    public static void toScoreShow(){
        SceneManager.LoadScene("ScoreShow");
    }
    public static void to1h(){
        SceneManager.LoadScene("Game_1");
    }
    public static void to2h(){
        SceneManager.LoadScene("Game_2");
    }
	public static void to3h(){
		SceneManager.LoadScene("Game_3");
    }
}
