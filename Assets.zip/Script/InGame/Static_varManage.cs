﻿using UnityEngine;
using System.Collections;

public static class varManage{

    public static int bulletDamage = 10;
    public static float playerSpd = 15f;
    public static int score = 0;
    public static int death = 0;
    public static int player = 1;
    public static int skillLeft = 3;

    public static int totalScore = 0;

    public static void clear () {
        bulletDamage = 10;
        playerSpd = 15f;
        score = 0;
        death = 0;
        player = 1;
        skillLeft = 0;
        HP_manage.bossHP = HP_manage.bossHPMax;
        HP_manage.bossHPf = 1;
        HP_manage.bossPhase = 0;
    }

}
