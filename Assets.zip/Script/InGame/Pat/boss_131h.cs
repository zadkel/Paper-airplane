﻿using UnityEngine;
using System.Collections;

public class boss_131h : MonoBehaviour {
	public GameObject bOrange;
	public GameObject hBlack;
	int shot;
	int i;
	int j;
	float k;
	float theta;
	float timer=1;
	float timer2;
	bool D;
	float Dtimer;
	float Dtimer2;
	// Use this for initialization
	void Start () {
		if (Difficulty.identity == "Hard") {
			D = true;
		} else if (Difficulty.identity == "Normal") {
			D = false;
		}
		if (D) {
			Dtimer=3;
			Dtimer2 = 0.1f;
		} else {
			Dtimer =5;
			Dtimer2 = 0.3f;
		}
		shot =36;

	}
	
	// Update is called once per frame
	void Update () {
		k = Random.Range (-10f, 10f);
		timer -= Time.deltaTime;
		timer2 -= Time.deltaTime;

		if (timer < 0) {
			timer = Dtimer;
			for (j = 0; j < shot; j++) {
				i = Number.Sequence;
				Number.Sequence++;

				theta = 2 * Mathf.PI * i / shot;
				Instantiate (bOrange, tPosition.tVec + new Vector3 (10 * Mathf.Cos (theta), 10 * Mathf.Sin (theta), 0),Quaternion.Euler(0,0, theta * 180 / Mathf.PI+90));
				 //플레이어 가두기
			}
		}

		if (timer2 < 0) {
			timer2 = Dtimer2;
			for (j = 0; j < 12; j++) {
				Instantiate (hBlack, transform.position + new Vector3 (k*2, 0, 0), Quaternion.Euler (0, 0, k*6));//두번째 탄
			}
		}




	}
}
