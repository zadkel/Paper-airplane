﻿using UnityEngine;
using System.Collections;

public class Pat_101h : MonoBehaviour {

	int shot;
	int i;
	float sp;
	float accel;
	float degree;
	bool D;
	// Use this for initialization
	void Start () {
		if (Difficulty.identity == "Hard") {
			D = true;
		} else if (Difficulty.identity == "Normal") {
			D = false;
		}

		if (D) {
			shot = 12;
		} else {
			shot = 8;
		}

		i = Number.Sequence;
		Number.Sequence++;
		sp = ((i / shot) %3 + 2) *5;//속도 shot번의 턴 동안 같은 숫자 나오게 하기
		accel=3;
		degree = 360.0f * i / shot;
		transform.Rotate (0, 0, degree);
	}

	// Update is called once per frame
	void Update () {
		sp += accel*Time.deltaTime;
		transform.Translate (0, sp * Time.deltaTime, 0);

		if (transform.position.x > 25 || transform.position.x < -25 || transform.position.y > 25 || transform.position.y < -25) {
			Destroy (this.gameObject);
		}


	}
}
