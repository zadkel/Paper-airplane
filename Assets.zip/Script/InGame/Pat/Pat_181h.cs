﻿using UnityEngine;
using System.Collections;

public class Pat_181h : MonoBehaviour {
	float sp;
	public float timer;
	Vector3 forwordVec;
	public bool RotateTrigger=false;
	public float r;
	bool D;
	float Dangle;
	// Use this for initialization
	void Start () {
		if (Difficulty.identity == "Hard") {
			D = true;
		} else if (Difficulty.identity == "Normal") {
			D = false;
		}
		if (D) {
			Dangle = 60f;
			sp = 20;
		} else {
			Dangle = 45f;
			sp = 15;
		}
	
	}
	
	// Update is called once per frame
	void Update () {
		timer -= Time.deltaTime;
		forwordVec = (this.transform.localRotation * Vector3.up).normalized;
		transform.position -= forwordVec * sp * Time.deltaTime;//방향따라 전진

		r = transform.eulerAngles.z;//object의 로컬축
		if (r > 180) {
			r = r - 360;
		}

				
		if (boss_181h.windTrigger == "Right") {
			transform.Rotate (0, 0, 80* Time.deltaTime);
			if (r > Dangle) {
				transform.rotation = Quaternion.Euler (0, 0, Dangle);
			}
		} 
		if (boss_181h.windTrigger == "Left") {
			transform.Rotate (0, 0, -80 * Time.deltaTime);
			if (r <-Dangle) {
				transform.rotation = Quaternion.Euler (0, 0, 360-Dangle);
			}
		}



		if (transform.position.y < -21) {
			Destroy (this.gameObject);
		}
	}
}
