﻿using UnityEngine;
using System.Collections;

public class Difficulty : MonoBehaviour {
	public static string identity = "Hard";
	//public static string identity = "Normal";
}