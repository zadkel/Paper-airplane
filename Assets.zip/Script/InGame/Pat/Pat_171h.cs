﻿using UnityEngine;
using System.Collections;

public class Pat_171h : MonoBehaviour {
	int i;
	public float k;
	float degree;
	float shot=8;
	float sp=10;
	Vector3 forwordVec;
	bool D;
	// Use this for initialization
	void Start () {
		if (Difficulty.identity == "Hard") {
			D = true;
		} else if (Difficulty.identity == "Normal") {
			D = false;
		}
		if (D) {
			shot = 7;
			sp = 10;
		} else {
			shot = 7;
			sp = 8;
		}
		transform.Translate (0, 0, 5);
		i = Number.Sequence%5;
		Number.Sequence++;
		k = Mathf.Cos (Mathf.PI * Number.Sequence);
		degree = 360f * i / shot;
		transform.Rotate (0, 0, degree);
		forwordVec = (transform.localRotation * Vector3.up).normalized;
	}
	
	// Update is called once per frame
	void Update () {
		transform.position += forwordVec * sp * Time.deltaTime;
		transform.Rotate (0, 0, 50*k * Time.deltaTime);

		if (transform.position.x > 40 || transform.position.x < -40 || transform.position.y > 40 || transform.position.y < -40) {
			Destroy (this.gameObject);
		}


	}
}
