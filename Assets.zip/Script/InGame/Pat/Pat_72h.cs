﻿using UnityEngine;
using System.Collections;

public class Pat_72h : MonoBehaviour {
	float sp;
	Vector3 waveVec;
	bool D;
	float k;
	// Use this for initialization
	void Start () {
		if (Difficulty.identity == "Hard") {
			D = true;
		} else if (Difficulty.identity == "Normal") {
			D = false;
		}

		if (D) {
			sp = 10;
		} else {
			sp = 5;
		}

		k = Random.Range (-1f, 1f);
		waveVec = new Vector3 (k, 0, 0);

	}
	
	// Update is called once per frame
	void Update () {
		

		transform.position += (waveVec*5 + Vector3.down * sp )* Time.deltaTime;
		transform.Rotate (0, 0, 100 *k* Time.deltaTime);
		if (transform.position.y<-40){
			Destroy (gameObject);
		}



	}
}
