﻿using UnityEngine;
using System.Collections;

public class Pat_121h : MonoBehaviour {
	public GameObject gYellow;
	int shot;
	int j;
	float k;
	float tri;
	float t;
	bool D;
	float triC;
	// Use this for initialization
	void Start () {
		k = Random.Range (0f, 360f);
		if (Difficulty.identity == "Hard") {
			D = true;
		} else if (Difficulty.identity == "Normal") {
			D = false;
		}
		if (D) {
			shot = 12;
			triC = (1.5f + k / 72);
		} else {
			shot = 8;
			triC = (2 + k / 72);
		}

		

		for (j = 0; j < shot; j++) {
			Number.Sequence++;
			GameObject newObject = Instantiate (gYellow, transform.position, Quaternion.Euler (0, 0, k))as GameObject;
			newObject.transform.parent = this.gameObject.transform;
		}
	}





	// Update is called once per frame
	void Update () {
		t += Time.deltaTime;
		tri = Mathf.Sin (k/180 * Mathf.PI + t);
		transform.Rotate (0, 0, tri/triC);




		if (transform.position.y < -40) {
			Destroy (this.gameObject);
		}


		if (t > 10) {
			Destroy (gameObject);
		}








	}
}
