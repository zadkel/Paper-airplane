﻿using UnityEngine;
using System.Collections;

public class boss_32h : MonoBehaviour {
	public GameObject cRed;
	float timer = 1f;
	int j;
	float k;
	bool D;
	float Dtimer;
	int Dj;
	// Use this for initialization
	void Start () {
		if (Difficulty.identity == "Hard") {
			D = true;
		} else if (Difficulty.identity == "Normal") {
			D = false;
		}

		if (D) {
			Dtimer = 1f;
			Dj = 20;
		} else {
			Dtimer = 2f;
			Dj = 12;
		}

	}

	// Update is called once per frame
	void Update () {
		timer -= Time.deltaTime;
		k = Random.Range (0f, 360f);
		if (timer < 0) {
			timer = Dtimer;
			for (j = 0; j < Dj; j++) {
				Instantiate (cRed, transform.position,Quaternion.Euler(0,0,k));
			}
		}






	}
}
