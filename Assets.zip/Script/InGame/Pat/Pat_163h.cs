﻿using UnityEngine;
using System.Collections;

public class Pat_163h : MonoBehaviour {
	Vector3 traceVec;
	float sp = 0;
	float accel;
	float degree;
	bool D;
	float t;
	// Use this for initialization
	void Start () {
		if (Difficulty.identity == "Hard") {
			D = true;
		} else if (Difficulty.identity == "Normal") {
			D = false;
		}
		if (D) {
			accel = 6;
		} else {
			accel = 4;
		}
		degree = Mathf.Atan2 (tPosition.ty - transform.position.y, tPosition.tx - transform.position.x);
		transform.rotation = Quaternion.Euler (0f, 0f, degree * 180f / Mathf.PI - 90f);
	}

	// Update is called once per frame
	void Update () {
		sp += accel * Time.deltaTime;
		transform.Translate (0, sp * Time.deltaTime, 0);

		if (transform.position.x > 25 || transform.position.x < -25 || transform.position.y > 25 || transform.position.y < -25) {
			Destroy (this.gameObject);
		}


	}
}
