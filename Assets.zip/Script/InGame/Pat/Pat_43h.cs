﻿using UnityEngine;
using System.Collections;


public class Pat_43h : MonoBehaviour {
	public static float dumRotation;
	public static float dumSpeed;

	float sp ;
	float degree;
	bool D;
	float Dsp;
	// Use this for initialization
	void Start () {
		if (Difficulty.identity == "Hard") {
			D = true;
		} else if (Difficulty.identity == "Normal") {
			D = false;
		}

		if (D) {
			Dsp = 15f;
		} else {
			Dsp = 12f;
		}

	}
	
	// Update is called once per frame
	void Update () {
		sp = Random.Range (10f, Dsp);
		degree = Mathf.Atan2 (tPosition.ty - transform.position.y, tPosition.tx - transform.position.x);
		transform.rotation = Quaternion.Euler (0f, 0f, degree * 180f / Mathf.PI - 90f);
		dumRotation = degree;//더미의 각도=탄 각도
		dumSpeed = sp;//탄스피드 랜덤







	}
}
