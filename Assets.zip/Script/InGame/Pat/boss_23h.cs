﻿using UnityEngine;
using System.Collections;

public class boss_23h : MonoBehaviour {
	public GameObject aBlue;
	float timer = 0.3f;
	int j;
	int k;
	bool D;
	float Dtimer;
	// Use this for initialization
	void Start () {
		if (Difficulty.identity == "Hard") {
			D = true;
		} else if (Difficulty.identity == "Normal") {
			D = false;
		}

		if (D) {
			Dtimer = 0.1f;
		} else {
			Dtimer = 0.2f;
		}
	
	}
	
	// Update is called once per frame
	void Update () {
		timer -= Time.deltaTime;
		if (timer < 0) {
			timer = Dtimer;
			k = -1*Number.Sequence;
			for (j = 0; j < 4; j++) {
				Instantiate (aBlue, transform.position, Quaternion.Euler (0, 0, k));
			}
		}


	}
}
