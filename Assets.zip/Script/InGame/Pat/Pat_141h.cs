﻿using UnityEngine;
using System.Collections;

public class Pat_141h : MonoBehaviour {
	Vector3 RanVec;
	public float timer=1;
	float sp=8f;
	float accel = 0.5f;
	public float scale;
	float rate;
	bool scaleTrigger=false;


	// Use this for initialization
	void Start () {
		RanVec = (new Vector3 (Random.Range (-1f, 1f), Random.Range (-3f, -1f), 0)).normalized;
		scale = transform.localScale.x;
	}
	
	// Update is called once per frame
	void Update () {
		
		sp -= accel * Time.deltaTime;

		transform.position +=  RanVec* sp* Time.deltaTime;//벡터만큼 이동

		if (sp<0||scaleTrigger) {
			sp = 0;//가까이 오면 멈춤
		}




		if (boss_141h.burst) {
			scaleTrigger = true;

		}

		if (scaleTrigger){
			timer -= Time.deltaTime;
			if (scale < 10&&timer<0) {
				transform.localScale += new Vector3 (40 * Time.deltaTime, 40 * Time.deltaTime, 0);
				scale +=40 * Time.deltaTime;
			}
			if (timer < -2) {
				Destroy (gameObject);
			}
		}





	}
}
