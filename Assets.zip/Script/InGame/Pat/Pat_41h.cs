﻿using UnityEngine;
using System.Collections;

public class Pat_41h : MonoBehaviour {
	public GameObject dRed;
	int shot;
	int i;
	float sp;
	float accel;
	float degree;
	bool D;
	// Use this for initialization
	void Start () {
		if (Difficulty.identity == "Hard") {
			D = true;
		} else if (Difficulty.identity == "Normal") {
			D = false;
		}

		if (D) {
			shot = 8;
		} else {
			shot = 6;
		}
		i = Number.Sequence;
		Number.Sequence++;
		sp = ((Number.Sequence / shot) %3 + 1.5f) *10;//속도 shot번의 턴 동안 같은 숫자 나오게 하기
		accel=sp;
		degree = 360.0f * i / shot;
		transform.Rotate (0, 0, degree);
	}

	// Update is called once per frame
	void Update () {
		sp -= accel*Time.deltaTime;//1초동안 속도 0으로 감속
		transform.Translate (0, sp * Time.deltaTime, 0);

		if (sp < 0) {
			sp = 0;

			Instantiate (dRed, transform.position, Quaternion.identity);
			Destroy (this.gameObject);
		}


	
	}
}
