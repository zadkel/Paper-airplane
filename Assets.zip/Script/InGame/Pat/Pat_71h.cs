﻿using UnityEngine;
using System.Collections;

public class Pat_71h : MonoBehaviour {
	float sp;
	bool D;
	// Use this for initialization
	void Start () {
		if (Difficulty.identity == "Hard") {
			D = true;
		} else if (Difficulty.identity == "Normal") {
			D = false;
		}

		if (D) {
			sp = 10;
		} else {
			sp = 5;
		}

	}
	
	// Update is called once per frame
	void Update () {
		//sp += accel * Time.deltaTime;
		transform.Translate (0, -sp * Time.deltaTime, 0);

		if (transform.position.y<-40){
			Destroy (gameObject);
		}


	}
}
