﻿using UnityEngine;
using System.Collections;

public class Pat_21h : MonoBehaviour {
	int i;
	int shot;
	float sp = 10.0f;
	float degree;
	// Use this for initialization
	void Start () {
		i = Number.Sequence;
		Number.Sequence++;
		shot = 4;
		degree = 360.0f * i / shot;
		transform.Rotate (0, 0, degree);
	}
	
	// Update is called once per frame
	void Update () {
		transform.Translate (0, -sp * Time.deltaTime, 0);



		if (transform.position.x > 21 || transform.position.x < -21 || transform.position.y > 21 || transform.position.y < -21) {
			Destroy (this.gameObject);
		}






	}

}
