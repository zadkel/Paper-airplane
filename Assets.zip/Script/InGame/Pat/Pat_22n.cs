﻿using UnityEngine;
using System.Collections;

public class Pat_22n : MonoBehaviour {

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}
}
