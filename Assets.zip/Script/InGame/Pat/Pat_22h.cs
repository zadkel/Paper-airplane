﻿using UnityEngine;
using System.Collections;

public class Pat_22h : MonoBehaviour {
	float sp = 10;
	float degree;
	// Use this for initialization
	void Start () {
		transform.Translate (0, 0, 1);

		degree = Mathf.Atan2 (tPosition.ty - transform.position.y, tPosition.tx - transform.position.x);
		transform.rotation = Quaternion.Euler (0f, 0f, degree * 180f / Mathf.PI + 90f);
	}
	
	// Update is called once per frame
	void Update () {
		transform.Translate (0, -sp * Time.deltaTime, 0);

		if (transform.position.x > 25 || transform.position.x < -25 || transform.position.y > 25 || transform.position.y < -25) {
			Destroy (this.gameObject);
		}

	
	}
}
