﻿using UnityEngine;
using System.Collections;

public class Pat_142h : MonoBehaviour {
	int i;
	float degree;
	float shot=24;
	float sp;
	bool D;

	// Use this for initialization
	void Start () {
		if (Difficulty.identity == "Hard") {
			D = true;
		} else if (Difficulty.identity == "Normal") {
			D = false;
		}
		if (D) {
			sp = 10f;
		} else {
			sp = 5;
		}
		i = Number.Sequence;
		Number.Sequence++;
		degree = 360f * i / shot;
		transform.Rotate (0, 0, degree);
	}

	// Update is called once per frame
	void Update () {
		transform.Translate (0, sp * Time.deltaTime, 0);

		if (transform.position.x > 40 || transform.position.x < -40 || transform.position.y > 40 || transform.position.y < -40) {
			Destroy (this.gameObject);
		}


	}
}
