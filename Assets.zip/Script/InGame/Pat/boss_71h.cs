﻿using UnityEngine;
using System.Collections;

public class boss_71h : MonoBehaviour {
	public GameObject waterBall;
	public GameObject fBlue;
	float timer=0;
	float timer2=0;
	int j;
	bool D;
	float Dtimer;
	int Dj;
	// Use this for initialization
	void Start () {
		if (Difficulty.identity == "Hard") {
			D = true;
		} else if (Difficulty.identity == "Normal") {
			D = false;
		}

		if (D) {
			Dtimer = 0.5f;
			Dj = 30;
		} else {
			Dtimer = 1f;
			Dj = 20;
		}

	}
	
	// Update is called once per frame
	void Update () {
		timer -= Time.deltaTime;
		timer2 -= Time.deltaTime;
		if (timer < 0) {
			timer = Dtimer;
			for (j = 0; j < Dj; j++) {
				Instantiate (waterBall, new Vector3 (Random.Range (-20, 20), 30, -1), Quaternion.identity);
			}
		}

		if (timer2 < 0) {
			for (j = 0; j < 2; j++) {
				timer2 = Dtimer;
				Instantiate (fBlue, new Vector3 (Random.Range (-20f, 20f), 28-0.7f, 0), Quaternion.identity);
			}
		}

	}
}
