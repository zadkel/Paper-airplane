﻿using UnityEngine;
using System.Collections;

public class Pat_131h : MonoBehaviour {
	float sp=10;
	int i;
	bool D;
	float Dangle;
	// Use this for initialization
	void Start () {
		if (Difficulty.identity == "Hard") {
			D = true;
		} else if (Difficulty.identity == "Normal") {
			D = false;
		}
		if (D) {
			Dangle = 15;
		} else {
			Dangle = 20;
		}
		i = Number.Sequence;
		Number.Sequence++;
		transform.Rotate (0, 0, Dangle * Mathf.Cos (i * Mathf.PI));
	}
	
	// Update is called once per frame
	void Update () {
		transform.Translate (0, sp * Time.deltaTime, 0);

		if (transform.position.x > 40 || transform.position.x < -40 || transform.position.y > 40 || transform.position.y < -40) {
			Destroy (this.gameObject);
		}
	}
}
