﻿using UnityEngine;
using System.Collections;

public class Pat_12h : MonoBehaviour {
	float sp;
	bool D;
	// Use this for initialization
	void Start () {
		transform.Rotate (0, 0, 180);
		if (Difficulty.identity == "Hard") {
			D = true;
		} else if (Difficulty.identity == "Normal") {
			D = false;
		}

		if (D) {
			sp = 5;
		} else {
			sp = 7;
		}
	}
	
	// Update is called once per frame
	void Update () {
	

		transform.Translate (0, sp * Time.deltaTime, 0);//이동


		if (transform.position.x > 21 || transform.position.x < -21 || transform.position.y > 21 || transform.position.y < -21) {
			Destroy (this.gameObject);
		}
		//범위 밖으로 나갈때 삭제

	}
}
