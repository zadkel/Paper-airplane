﻿using UnityEngine;
using System.Collections;

public class boss_51h : MonoBehaviour {
	public GameObject dummy;
	float timer;
	bool D;
	float Dtimer;
	// Use this for initialization
	void Start () {
		if (Difficulty.identity == "Hard") {
			D = true;
		} else if (Difficulty.identity == "Normal") {
			D = false;
		}

		if (D) {
			Dtimer = 0.2f;
		} else {
			Dtimer = 0.4f;
		}

	
	}
	
	// Update is called once per frame
	void Update () {
		


		timer -= Time.deltaTime;
		if (timer < 0) {
			timer = Dtimer;
			Instantiate (dummy, new Vector3 (Random.Range (-30, 30), 35, -1), Quaternion.identity);
		}










	}
}
