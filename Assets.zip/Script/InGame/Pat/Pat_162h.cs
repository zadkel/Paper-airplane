﻿using UnityEngine;
using System.Collections;

public class Pat_162h : MonoBehaviour {
	public GameObject Missaile;
	Vector3 traceVec;
	int i;
	float degree;
	float shot=25;
	float sp=7;
	bool D;
	int Dshot;
	// Use this for initialization
	void Start () {
		if (Difficulty.identity == "Hard") {
			D = true;
		} else if (Difficulty.identity == "Normal") {
			D = false;
		}
		if (D) {
			sp = 10;
			Dshot = 5;
		} else {
			sp= 5;
			Dshot = 4;
		}
		i = Number.Sequence%Dshot;
		Number.Sequence++;
		degree = 360f * i / shot;
		transform.Rotate (0, 0, degree);
	}

	// Update is called once per frame
	void Update () {
		transform.Translate (0, sp * Time.deltaTime, 0);

		if (transform.position.x > 20 || transform.position.x < -20 || transform.position.y > 20 || transform.position.y < -20) {
			Instantiate (Missaile, transform.position, Quaternion.identity);
			Destroy (gameObject);
		}


	}
}
