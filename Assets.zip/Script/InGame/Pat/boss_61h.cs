﻿using UnityEngine;
using System.Collections;

public class LRcontroll:MonoBehaviour  {
	public static string Angle;
}

public class boss_61h : MonoBehaviour {
	public GameObject dummy;
	string angle="Right";
	float timer=1;
	bool D;
	float Dtimer;
	// Use this for initialization
	void Start () {
		if (Difficulty.identity == "Hard") {
			D = true;
		} else if (Difficulty.identity == "Normal") {
			D = false;
		}

		if (D) {
			Dtimer = 3;
		} else {
			Dtimer = 5;
		}

		LRcontroll.Angle = angle;
	}
	
	// Update is called once per frame
	void Update () {
		
		timer -= Time.deltaTime;


		if (timer < 0) {
			if (angle == "Left") {
				angle = "Right";
			} else if (angle == "Right") {
				angle = "Left";
			}
			LRcontroll.Angle = angle;
			timer = Dtimer;
			Instantiate (dummy, transform.position, Quaternion.identity);
		


		}






	}
}
