﻿using UnityEngine;
using System.Collections;

public class Pat_81h : MonoBehaviour {
	float sp=0;
	float accel;
	bool D;
	float Daccel;
	// Use this for initialization
	void Start () {
		if (Difficulty.identity == "Hard") {
			D = true;
		} else if (Difficulty.identity == "Normal") {
			D = false;
		}

		if (D) {
			Daccel = 5f;
		} else {
			Daccel = 3f;
		}


		accel = Random.Range (0f, Daccel);
	}
	
	// Update is called once per frame
	void Update () {
		sp += accel * Time.deltaTime;
		transform.Translate (0, -sp * Time.deltaTime, 0);

		if (transform.position.y<-40){
			Destroy (gameObject);
		}

	}
}
