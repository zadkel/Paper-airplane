﻿using UnityEngine;
using System.Collections;

public class boss_101h : MonoBehaviour {
	public GameObject dBlue;
	public GameObject dRed;

	public float timer =2f;
	int i;
	int j;
	float k;
	bool D;
	float Dtimer;
	int shot;
	// Use this for initialization
	void Start () {
		if (Difficulty.identity == "Hard") {
			D = true;
		} else if (Difficulty.identity == "Normal") {
			D = false;
		}

		if (D) {
			Dtimer = 0.2f;
			shot = 12;
		} else {
			Dtimer = 0.3f;
			shot = 8;
		}

	}

	// Update is called once per frame
	void Update () {
		timer -= Time.deltaTime;


		if (timer < 0) {
			
			if (i < 3) {
				i++;
				timer=Dtimer;//총쏘는 간격
				k = Random.Range (0f, 360f);//각도 랜덤
				for (j = 0; j < shot; j++) {
					Instantiate (dBlue, transform.position, Quaternion.Euler (0, 0, k));
				}
				for (j = 0; j <shot; j++) {
					Instantiate (dRed, transform.position, Quaternion.Euler (0, 0, k+180f/12));
				}
			} else {
				i = 0;
				timer = Dtimer;
			}


		}



	}
}

