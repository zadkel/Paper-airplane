﻿using UnityEngine;
using System.Collections;

public class Pat_91h : MonoBehaviour {
	Vector3 magnetVec;
	float sp;
	bool D;
	// Use this for initialization
	void Start () {
		if (Difficulty.identity == "Hard") {
			D = true;
		} else if (Difficulty.identity == "Normal") {
			D = false;
		}

		if (D) {
			sp = 5;
		} else {
			sp=3;
		}
		magnetVec = (boss_91h.Bpos - transform.position).normalized;
	}
	
	// Update is called once per frame
	void Update () {
		

		transform.position += magnetVec * sp * Time.deltaTime;

		if (Vector3.Distance (boss_91h.Bpos, transform.position) < 1) {
			Destroy (gameObject);
		}

	}
}
