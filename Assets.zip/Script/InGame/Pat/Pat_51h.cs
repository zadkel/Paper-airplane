﻿using UnityEngine;
using System.Collections;

public class Pat_51h : MonoBehaviour {
	public GameObject snow;
	float sp=10f;
	float r,r2;
	int shot;
	int i;
	int j;
	bool D;

	// Use this for initialization
	void Start () {
		if (Difficulty.identity == "Hard") {
			D = true;
		} else if (Difficulty.identity == "Normal") {
			D = false;
		}

		if (D) {
			shot = 12;
		} else {
			shot = 6;
		}
			
		r = Random.Range (0f, 1f);
		r2 = Random.Range (0f, 1f);

		for(j=0;j<shot;j++){
			i = Number.Sequence;
			Number.Sequence++;
			GameObject newObject = Instantiate (snow, new Vector2 (transform.position.x + (10 * r2 + 2) * Mathf.Cos (2 * Mathf.PI * i / shot), transform.position.y + (10 * r2 + 2) * Mathf.Sin (2 * Mathf.PI * i / shot)), Quaternion.identity) as GameObject;
			newObject.transform.parent = this.gameObject.transform;
		}

	
	}
	
	// Update is called once per frame
	void Update () {



		transform.Translate (sp * Time.deltaTime * (r - 0.5f) , -sp * Time.deltaTime , 0);

		if (transform.position.y < -40) {
			Destroy (this.gameObject);
		}










	
	}
}
