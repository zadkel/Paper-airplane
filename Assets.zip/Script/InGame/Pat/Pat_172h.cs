﻿using UnityEngine;
using System.Collections;

public class Pat_172h : MonoBehaviour {
	int i;
	float k;
	float degree;
	float shot=30;
	float sp=20;
	Vector3 forwordVec;
	bool D;
	// Use this for initialization
	void Start () {
		if (Difficulty.identity == "Hard") {
			D = true;
		} else if (Difficulty.identity == "Normal") {
			D = false;
		}
		if (D) {
			shot = 30;
			sp = 20;
		} else {
			shot = 20;
			sp = 15;
		}
		i = Number.Sequence;
		Number.Sequence++;
		k = Mathf.Cos (Mathf.PI * Random.Range(0f,2f));
		degree = 360f * i / shot;
		transform.Rotate (0, 0, degree);
		forwordVec = (this.transform.localRotation * Vector3.up).normalized;
	}
	
	// Update is called once per frame
	void Update () {
		transform.position += forwordVec * sp * Time.deltaTime;
		transform.Rotate (0, 0, 70*k * Time.deltaTime);

		if (transform.position.x > 40 || transform.position.x < -40 || transform.position.y > 40 || transform.position.y < -40) {
			Destroy (this.gameObject);
		}

	}
}
