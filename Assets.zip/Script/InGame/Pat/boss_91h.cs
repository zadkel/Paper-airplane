﻿using UnityEngine;
using System.Collections;

public class boss_91h : MonoBehaviour {
	public static Vector3 Bpos;
	public GameObject gBlue;
	public GameObject star;
	float timer;
	float timer2;
	int i,j;
	int shot;
	float theta;
	float k;
	bool D;
	float Dtimer;
	float Dtimer2;
	// Use this for initialization
	void Start () {
		if (Difficulty.identity == "Hard") {
			D = true;
		} else if (Difficulty.identity == "Normal") {
			D = false;
		}

		if (D) {
			Dtimer =0.5f;
			Dtimer2 = 1;
			shot = 24;
		} else {
			Dtimer = 1f;
			Dtimer2 = 2;
			shot=18;
		}
			

		timer2 = 5;
		Bpos = 10 * Vector3.up;
	}
	
	// Update is called once per frame
	void Update () {

		k = Random.Range (0f, 2f);

		timer -= Time.deltaTime;
		timer2 -= Time.deltaTime;
		if (timer < 0) {
			timer = Dtimer;



			for (j = 0; j < shot; j++) {
				i = Number.Sequence;
				Number.Sequence++;
				theta = 2 * Mathf.PI * i / shot + k * Mathf.PI;

				Instantiate (gBlue, Bpos + new Vector3 (35 * Mathf.Cos (theta), 35 * Mathf.Sin (theta), 1), Quaternion.identity);
			}
		}

		if (timer2 < 0) {
			timer2 = Dtimer2;
			for (j = 0; j < shot; j++) {
				Instantiate (star, transform.position, Quaternion.Euler (0, 0, k*180));
			}
		}

	}
}
