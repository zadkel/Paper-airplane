﻿using UnityEngine;
using System.Collections;

public class Pat_161h : MonoBehaviour {
	int shot;
	int i;
	public float sp;
	// Use this for initialization
	void Start () {
		i = Number.Sequence;
		Number.Sequence++;
		sp = (i %3 + 2) *3;
	}
	
	// Update is called once per frame
	void Update () {
		transform.Translate (0, -sp * Time.deltaTime, 0);

		if ( transform.position.y > 25 || transform.position.y < -25) {
			Destroy (this.gameObject);
		}


	}
}
