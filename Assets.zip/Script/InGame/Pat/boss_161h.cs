﻿using UnityEngine;
using System.Collections;

public class boss_161h : MonoBehaviour {
	public GameObject thunder;
	public float timer =1;
	int i;
	int j;
	float k;
	bool D;
	float Dtimer;
	// Use this for initialization
	void Start () {
		if (Difficulty.identity == "Hard") {
			D = true;
		} else if (Difficulty.identity == "Normal") {
			D = false;
		}
		if (D) {
			Dtimer = 0.5f;
		} else {
			Dtimer = 1;
		}
	}
	
	// Update is called once per frame
	void Update () {
		timer -= Time.deltaTime;
		if (timer < 0) {
			timer = Dtimer;//총쏘는 간격
			k=Random.Range(-20f,20f);
			for (j = 0; j < 3; j++) {
					Instantiate (thunder, new Vector3 (k,k/8+15,0), Quaternion.identity);
			}

		}
			

	}
}
