﻿using UnityEngine;
using System.Collections;

public class boss_22h : MonoBehaviour {
	public GameObject cRed;
	float timer;
	bool D;
	float Dtimer;
	// Use this for initialization
	void Start () {
		if (Difficulty.identity == "Hard") {
			D = true;
		} else if (Difficulty.identity == "Normal") {
			D = false;
		}

		if (D) {
			Dtimer = 1.3f;
			timer = 1.5f;
		} else {
			Dtimer = 2.6f;
			timer=1f;
		}

	}

	// Update is called once per frame
	void Update () {
		timer -= Time.deltaTime;
		if (timer < 0) {
			timer = Dtimer;

			Instantiate (cRed, transform.position, Quaternion.identity);
		}

	}
}
