﻿using UnityEngine;
using System.Collections;

public class boss_162h : MonoBehaviour {
	public GameObject gsky;

	public float timer =1;
	int i;
	int j;
	int shot;
	float k;
	bool D;
	float Dtimer;

	// Use this for initialization
	void Start () {
		if (Difficulty.identity == "Hard") {
			D = true;
		} else if (Difficulty.identity == "Normal") {
			D = false;
		}
		if (D) {
			Dtimer = 1;
			shot = 5;
		} else {
			Dtimer = 1.5f;
			shot = 4;
		}
		i = 0;
	}
	
	// Update is called once per frame
	void Update () {
		timer -= Time.deltaTime;
		if (timer < 0) {
			if (i < 5) {
				i++;
				timer = Dtimer;//총쏘는 간격
				k = Random.Range (0f, 360f);//각도 랜덤
				for (j = 0; j < shot; j++) {
					Instantiate (gsky, transform.position, Quaternion.Euler (0, 0, k));
				}
			} else {
				i = 0;
				timer = 2;
			}
				

		}



	}
}
