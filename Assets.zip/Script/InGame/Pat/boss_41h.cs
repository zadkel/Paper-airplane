﻿using UnityEngine;
using System.Collections;

public class boss_41h : MonoBehaviour {
	public GameObject dBlue;
	public GameObject dummy;
	float timer =2f;
	int j;
	float k;
	bool D;
	float Dtimer;
	int Dj;
	// Use this for initialization
	void Start () {
		if (Difficulty.identity == "Hard") {
			D = true;
		} else if (Difficulty.identity == "Normal") {
			D = false;
		}

		if (D) {
			Dtimer = 1f;
			Dj = 24;
		} else {
			Dtimer = 1.5f;
			Dj = 18;
		}
		Instantiate (dummy, transform.position, Quaternion.identity);
	}

	// Update is called once per frame
	void Update () {

		timer -= Time.deltaTime;
		if (timer < 0) {
			timer = Dtimer;//총쏘는 간격
			k = Random.Range (0f, 360f);//각도 랜덤
			for (j = 0; j < Dj; j++) {
				Instantiate (dBlue, transform.position, Quaternion.Euler (0, 0, k));
				//해당 각도만큼 돌림
			}

		}







	}
}
