﻿using UnityEngine;
using System.Collections;

public class boss_151h : MonoBehaviour {
	public GameObject goast;
	public float timer =1;
	int j;
	int shot;
	float k;
	bool D;
	float Dtimer;
	// Use this for initialization
	void Start () {
		if (Difficulty.identity == "Hard") {
			D = true;
		} else if (Difficulty.identity == "Normal") {
			D = false;
		}
		if (D) {
			Dtimer = 3f;
			shot = 12;
		} else {
			Dtimer = 3f;
			shot = 8;
		}
	}
	
	// Update is called once per frame
	void Update () {
		timer -= Time.deltaTime;
		if (timer < 0) {
			timer = Dtimer;//총쏘는 간격
			k = Random.Range (0f, 360f);//각도 랜덤
			for (j = 0; j <shot; j++) {
				Instantiate (goast, transform.position, Quaternion.Euler (0, 0, k));
			}
		}






	}
}
