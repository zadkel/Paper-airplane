﻿using UnityEngine;
using System.Collections;

public class Pat_11h : MonoBehaviour {
	public GameObject bRed;
	public int i;
	public int shot;
	public float sp;
	public float degree;

	bool D;
	float Dsp;
	float Dshot;
	// Use this for initialization
	void Start () {
		if (Difficulty.identity == "Hard") {
			D = true;
		} else if (Difficulty.identity == "Normal") {
			D = false;
		}

		if (D) {
			shot = 50;
		} else {
			shot = 40;
		}

		sp = 10f;

		i  = Number.Sequence;
		Number.Sequence ++;//1씩 증가 
		degree = 360.0f * i / shot;
		transform.Rotate (0, 0, degree);


	}
	
	// Update is called once per frame
	void Update () {


		sp -=10f*Time.deltaTime;//속도 감소

		transform.Translate (0, -sp *Time.deltaTime*4.7f, 0);//이동


		if (sp < 0.1f) {
			Instantiate (bRed, transform.position, transform.rotation);
			Destroy (this.gameObject);
		}
		//일정속도 이하일때 객채 바꿈




	
	}
}
