﻿using UnityEngine;
using System.Collections;

public class Pat_151h : MonoBehaviour {
	public GameObject Missile;
	int i;
	float degree;
	float shot=8;
	float sp=5;
	float timer=3;
	Vector3 forwordVec;
	bool D;
	float Dtimer;
	// Use this for initialization
	void Start () {
		if (Difficulty.identity == "Hard") {
			D = true;
		} else if (Difficulty.identity == "Normal") {
			D = false;
		}
		if (D) {
			shot = 12;
			Dtimer = 1;
		} else {
			shot = 8;
			Dtimer = 1.5f;
		}
		i = Number.Sequence;
		Number.Sequence++;
		degree = 360f * i / shot;
		transform.Rotate (0, 0, degree);
		forwordVec = (this.transform.localRotation * Vector3.up).normalized;
		transform.rotation = Quaternion.identity;
	}
	
	// Update is called once per frame
	void Update () {
		timer -= Time.deltaTime;
		transform.position += forwordVec * sp * Time.deltaTime;

		if (timer < 0) {
			timer =Dtimer;
			Instantiate (Missile, transform.position, Quaternion.identity);
		}





		if (transform.position.x > 21 || transform.position.x < -21 || transform.position.y > 21 || transform.position.y < -21) {
			Destroy (this.gameObject);
		}



	}
}
