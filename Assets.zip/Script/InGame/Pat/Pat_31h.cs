﻿using UnityEngine;
using System.Collections;

public class Pat_31h : MonoBehaviour {
	float sp=10f;
	float accel=1f;
	int shot;
	int i;
	float degree;
	// Use this for initialization
	void Start () {
		i = Number.Sequence;
		Number.Sequence++;
		shot = 8;
		degree = 360.0f * i / shot;
		transform.Rotate (0, 0, degree);
	}
	
	// Update is called once per frame
	void Update () {
		sp -= accel * Time.deltaTime;
		transform.Translate (0, sp * Mathf.Cos (Mathf.PI * i) * Time.deltaTime, 0);


		if (transform.position.x > 21 || transform.position.x < -21 || transform.position.y > 21 || transform.position.y < -21 || sp<0f) {
			Destroy (this.gameObject);
		}




	}
}
