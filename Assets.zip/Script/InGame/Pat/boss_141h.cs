﻿using UnityEngine;
using System.Collections;

public class boss_141h : MonoBehaviour {
	public static bool burst=false;

	public GameObject gwhite;
	public GameObject hGreen;
	public GameObject bossWave;

	float timer =0;
	float timer2;
	float timer3;
	int i;
	int j;
	float k;
	public int Paze;
	bool D;
	float Dtimer;
	float Dtimer3;
	// Use this for initialization
	void Start () {
		if (Difficulty.identity == "Hard") {
			D = true;
		} else if (Difficulty.identity == "Normal") {
			D = false;
		}
		if (D) {
			Dtimer = 0.2f;
			Dtimer3 = 0.5f;
		} else {
			Dtimer = 0.5f;
			Dtimer3 = 1f;
		}
		timer2 = 6;
		Paze = 0;
	}
	
	// Update is called once per frame
	void Update () {
		timer3 -= Time.deltaTime;
		timer -= Time.deltaTime;
		timer2 -= Time.deltaTime;


		if (Paze==0&&timer<0) {
			burst = false;
			Paze++;//0이하되면 다음 페이즈 
		}

		if (timer < 0) {
			if (Paze == 1) {
				timer = Dtimer;
				Instantiate (gwhite, new Vector3 (Random.Range (-20f, 20f), Random.Range (10f, 20f), 0)+Vector3.forward, Quaternion.identity);//생성

			}
		}

		if (timer2 < 0) {
			Instantiate (bossWave,transform.position, Quaternion.identity);//생성
			Paze =2;
		}

		if(Paze==2&&burst==false){
			timer = 3;
			timer2 = 10;
			burst=true;
			Paze=0;//폭발시키고 페이즈0
		}


		if (timer3 < 0&&Paze==1) {
			timer3 = Dtimer3;//총쏘는 간격
			k = Random.Range (0f, 360f);//각도 랜덤
			for (j = 0; j < 24; j++) {
				Instantiate (hGreen, transform.position, Quaternion.Euler (0, 0, k));

				//해당 각도만큼 돌림
			}
		}



	}
}
