﻿using UnityEngine;
using System.Collections;

public class Pat_111h : MonoBehaviour {
	int i;
	int shot;

	float sp;
	float accel;
	float degree;
	bool D;

	// Use this for initialization
	void Start () {

		if (Difficulty.identity == "Hard") {
			D = true;
		} else if (Difficulty.identity == "Normal") {
			D = false;
		}
		if (D) {
			shot = 91;
			sp = 8;
		} else {
			shot = 71;
			sp = 5;
		}
			
		i = Number.Sequence11;
		Number.Sequence11++;



		degree = 360f * i / shot;
		transform.Rotate (0, 0, degree);
	}

	// Update is called once per frame
	void Update () {
		//sp += accel*Time.deltaTime;
		transform.Translate (0, sp * Time.deltaTime, 0);

		if (transform.position.x > 25 || transform.position.x < -25 || transform.position.y > 25 || transform.position.y < -25) {
			Destroy (this.gameObject);
		}


	}
}
