﻿using UnityEngine;
using System.Collections;

public class Pat_112h : MonoBehaviour {
	int i;
	int shot;
	float timer=1;
	float sp ;
	float sp2;
	float accel;
	float degree;
	Vector3 targetVec;
	Vector3 traceVec;
	Vector3 traVec;
	bool timerTrigger=false;
	bool vecTrigger=false;
	bool D;
	// Use this for initialization
	void Start () {
		if (Difficulty.identity == "Hard") {
			D = true;
		} else if (Difficulty.identity == "Normal") {
			D = false;
		}
		if (D) {
			shot = 91;
			sp = 8;
		} else {
			shot = 71;
			sp = 5;
		}
		i = Number.Sequence11;
		Number.Sequence11++;


		accel=sp;
		degree = 360f * i / shot;
		transform.Rotate (0, 0, degree);



	}

	// Update is called once per frame
	void Update () {
		


		transform.Translate (0, sp * Time.deltaTime, 0);

		if (Vector3.Distance (transform.position, tPosition.tVec) < 10 ) {

			timerTrigger = true;
		}

		if (timerTrigger == true) {
			if (sp > 0) {
				sp -= accel * Time.deltaTime; //플레이어 주위에서 서서히 멈춤
			}
			timer -= Time.deltaTime;
		}


		if (timer < 0) {
			if (sp2 < 10) {
				sp2 += 0.5f*accel * Time.deltaTime;
			}
			if (vecTrigger == false) {
				vecTrigger = true;
				targetVec = tPosition.tVec;
				traVec = transform.position;
			}
		}//속도 멈춘상태에서 속도 5이하로 유도 벡터 저장


		if (vecTrigger == true) {
			
			traceVec = (targetVec-traVec).normalized;
			transform.position += traceVec * sp2 * Time.deltaTime;
		}//벡터 이동



		if (transform.position.x > 25 || transform.position.x < -25 || transform.position.y > 25 || transform.position.y < -25) {
			Destroy (this.gameObject);
		}


	}


}
