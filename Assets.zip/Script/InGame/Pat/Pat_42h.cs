﻿using UnityEngine;
using System.Collections;

public class Pat_42h : MonoBehaviour {
	float sp ;
	float degree;
	// Use this for initialization
	void Start () {
		sp = Pat_43h.dumSpeed;
			degree = Pat_43h.dumRotation;
		transform.Rotate (0, 0, degree* 180f / Mathf.PI - 90f);

	}

	// Update is called once per frame
	void Update () {
		transform.Translate (0, sp * Time.deltaTime, 0);

		if (transform.position.x > 40 || transform.position.x < -40 || transform.position.y > 40 || transform.position.y < -40) {
			Destroy (this.gameObject);
		}


	}
}
