﻿using UnityEngine;
using System.Collections;



public class Pat_62h : MonoBehaviour {
	int i;
	int shot;
	float ft;
	float t = 0;
	float degree;
	float timer;
	string angle;
	bool flag=false;
	bool D;

	// Use this for initialization
	void Start () {
		if (Difficulty.identity == "Hard") {
			D = true;
		} else if (Difficulty.identity == "Normal") {
			D = false;
		}

		if (D) {
			shot = 18;
		} else {
			shot = 12;
		}

		i  = Number.Sequence;
		Number.Sequence ++; 

		degree = 360.0f * i / shot;
		transform.Rotate (0, 0, degree);
		timer = 0;
		angle = LRcontroll.Angle;


	}
	
	// Update is called once per frame
	void Update () {
		timer += Time.deltaTime;




		ft = (-2 * t + 24) *0.3f *Time.deltaTime;//t에 관한 이차함수를 미분;
		t += Time.deltaTime;


		if (timer < 12) {
			if (angle == "Left") {
				transform.Translate (ft * Mathf.Cos (+Mathf.PI / 6), ft * Mathf.Sin (+Mathf.PI / 6), 0);
			} else if (angle == "Right") {
				transform.Translate (ft * Mathf.Cos (-Mathf.PI / 6), ft * Mathf.Sin (-Mathf.PI / 6), 0);
			}
		}
		//10초 전에 실행
		if (timer > 12 && !flag) {
			if (angle == "Left") {
				transform.Rotate (0, 0, 60);
			}
			if (angle == "Right") {
				transform.Rotate (0, 0, -60);
			}
			flag = true;
		}
		//방향 바꿔주는 일회용 조건문

		if (timer > 12) {
			if (angle == "Left") {
				transform.Translate (ft * Mathf.Cos (-Mathf.PI / 6), ft * Mathf.Sin (-Mathf.PI / 6), 0);
			} else if (angle == "Right") {
				transform.Translate (ft * Mathf.Cos (+Mathf.PI / 6), ft * Mathf.Sin (+Mathf.PI / 6), 0);
			}
		}
		//방향 바꾼후 이동



		if (timer > 24) {
			Destroy (this.gameObject);
		}


	}
}
