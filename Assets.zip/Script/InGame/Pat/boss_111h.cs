﻿using UnityEngine;
using System.Collections;

public class boss_111h : MonoBehaviour {
	public GameObject gBlue;
	public GameObject gRed;
	float timer =1f;
	int j;
	int shot;
	float k;
	bool D;
	float Dtimer;
	// Use this for initialization
	void Start (){
		if (Difficulty.identity == "Hard") {
			D = true;
		} else if (Difficulty.identity == "Normal") {
			D = false;
		}

		if (D) {
			Dtimer = 0.7f;
			shot = 90;
		} else {
			Dtimer = 1f;
			shot = 70;
		}

	}



	// Update is called once per frame
	void Update () {
		timer -= Time.deltaTime;
		if (timer < 0) {
			timer = Dtimer;//총쏘는 간격
			k = Random.Range (170f, 190f);//각도 랜덤

			Instantiate(gRed, transform.position, Quaternion.Euler (0, 0, k));
		for (j = 0; j < shot; j++) {
				Instantiate (gBlue, transform.position, Quaternion.Euler (0, 0, k));

				//해당 각도만큼 돌림
			}


		}
	}
}

