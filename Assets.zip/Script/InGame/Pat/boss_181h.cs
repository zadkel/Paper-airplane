﻿using UnityEngine;
using System.Collections;

public class boss_181h : MonoBehaviour {
	public GameObject leaf;
	float timer=1;
	float timer2=5;
	bool D;
	float Dtimer;
	public static string windTrigger="Right";
	// Use this for initialization
	void Start () {
		if (Difficulty.identity == "Hard") {
			D = true;
		} else if (Difficulty.identity == "Normal") {
			D = false;
		}
		if (D) {
			Dtimer = 0.04f;
		} else {
			Dtimer = 0.07f;
		}
	
	}
	
	// Update is called once per frame
	void Update () {
		timer -= Time.deltaTime;
		timer2 -= Time.deltaTime;
		if (timer < 0) {
			timer = Dtimer;
			Instantiate (leaf, new Vector3 (Random.Range (-40f, 40f), Random.Range (20f, 50f), -1), Quaternion.identity);
			if (windTrigger == "Right") {
				Instantiate (leaf, new Vector3 (Random.Range (-40f, -20f), Random.Range (-10f, 50f), -1), Quaternion.identity);
			} else if (windTrigger == "Left") {
				Instantiate (leaf, new Vector3 (Random.Range (20f, 40f), Random.Range (-10f, 50f), -1), Quaternion.identity);
			}
		}
		if (timer2 < 0) {
			timer2 = 5f;
			if (windTrigger == "Right") {
				windTrigger = "Left";
			} else if (windTrigger == "Left") {
				windTrigger = "Right";
			}
		}


	}
}
