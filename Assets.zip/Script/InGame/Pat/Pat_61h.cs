﻿using UnityEngine;
using System.Collections;

public class Pat_61h : MonoBehaviour {
	
	public GameObject eBlue;
	Vector3 disVec;
	Vector3 norVec;
	float sp = 5f ;
	float k;
	int shot;
	int j;
	string angle;

	bool D;
	// Use this for initialization
	void Start () {
		if (Difficulty.identity == "Hard") {
			D = true;
		} else if (Difficulty.identity == "Normal") {
			D = false;
		}

		if (D) {
			shot = 18;
		} else {
			shot = 12;
		}

		disVec = (tPosition.tVec - transform.position).normalized;
		norVec = (3 * Vector3.down + Vector3.right).normalized;
		k = Random.Range (0f, 360f);
		for(j=0;j<shot;j++){
			
			Number.Sequence++;
			GameObject newObject = Instantiate (eBlue,transform.position, Quaternion.Euler(0,0,k)) as GameObject;
			newObject.transform.parent = this.gameObject.transform;
			angle = LRcontroll.Angle;
		}



	}
	
	// Update is called once per frame
	void Update () {
		transform.position += norVec * sp * 0.5f* Time.deltaTime;

		if (angle == "Left") {
			transform.Rotate (0, 0, sp * 8 * Time.deltaTime);
		}else if (angle == "Right") {
			transform.Rotate (0, 0, -sp * 8 * Time.deltaTime);
		}


		if (transform.position.y < -120) {
			Destroy (this.gameObject);
		}



	}
}
