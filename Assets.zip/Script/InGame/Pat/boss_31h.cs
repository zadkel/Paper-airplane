﻿using UnityEngine;
using System.Collections;

public class boss_31h : MonoBehaviour {
	public GameObject aGreen;
	float i,j,k;
	float timer=1.0f;
	bool D;
	float Dtimer;
	int Dj;
	// Use this for initialization
	void Start () {
		if (Difficulty.identity == "Hard") {
			D = true;
		} else if (Difficulty.identity == "Normal") {
			D = false;
		}

		if (D) {
			Dtimer = 0.1f;
			Dj = 8;
		} else {
			Dtimer = 0.2f;
			Dj = 8;
		}

	}
	
	// Update is called once per frame
	void Update () {
		i += Time.deltaTime * 60;
		transform.position = new Vector2 (15*Mathf.Cos (Mathf.PI / 180 * 2 * i), 14 + 3*Mathf.Sin (Mathf.PI / 180 * 4 * i));


		timer-=Time.deltaTime;

		if(timer<0){
			timer = Dtimer;
			k = Number.Sequence;
			Number.Sequence++;
			for (j = 0; j < Dj; j++) {
			Instantiate (aGreen, transform.position, Quaternion.Euler (0, 0, k));
			}
		}






	}
}
