﻿using UnityEngine;
using System.Collections;

public class boss_81h : MonoBehaviour {
	public GameObject waterBall;
	float timer=0;
	int j;
	bool D;
	float Dtimer;
	// Use this for initialization
	void Start () {
		if (Difficulty.identity == "Hard") {
			D = true;
		} else if (Difficulty.identity == "Normal") {
			D = false;
		}

		if (D) {
			Dtimer = 0.01f;
		} else {
			Dtimer = 0.05f;
		}

	}
	
	// Update is called once per frame
	void Update () {
		timer -= Time.deltaTime;
		if (timer < 0) {
			timer = Dtimer;
				Instantiate (waterBall, new Vector3 (Random.Range (-20f, 20f),Random.Range (25f, 45f), -1), Quaternion.identity);
		}




	}
}
