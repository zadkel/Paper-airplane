﻿using UnityEngine;
using System.Collections;

public class destroyEffect : MonoBehaviour {
	float scale;
	// Use this for initialization
	void Start () {
		

	}
	
	// Update is called once per frame
	void Update () {
		scale = transform.localScale.x;
		transform.localScale += (Vector3.up + Vector3.right) * 10* Time.deltaTime;

		if (scale >1.5f) {
			Destroy (gameObject);
		}

	}
}
