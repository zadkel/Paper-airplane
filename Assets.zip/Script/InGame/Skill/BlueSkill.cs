﻿using UnityEngine;
using System.Collections;

public class BlueSkill : MonoBehaviour {

    public GameObject Shield;
    public GameObject ShieldObj;
    public float SkillTime = 3f;
    float timer;
    bool sActive;
    // Use this for initialization
    void Start () {
        timer = SkillTime;
        sActive = false;
    }

    // Update is called once per frame
    void Update () {

        if(Input.GetKeyDown(KeyCode.X)&&!sActive&&varManage.skillLeft>0){
            varManage.skillLeft--;
            ShieldObj = Instantiate (Shield,transform.position,new Quaternion()) as GameObject;
            timer = SkillTime;
            sActive = true;
        }
        if(timer < 0 && sActive){
            sActive = false;
            Destroy(ShieldObj);
        }
        timer -= Time.deltaTime;

    }
}
