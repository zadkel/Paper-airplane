﻿using UnityEngine;
using System.Collections;

public class Skill_bDestory : MonoBehaviour {
	public GameObject effectBlue;
	public GameObject effectRed;
	public GameObject effectGreen;
	public GameObject effectYellow;

    void OnTriggerEnter2D(Collider2D col)
    {
		if (col.CompareTag ("Bullet_UnBroken")) {
			Destroy (col.gameObject);
			Instantiate (effectYellow, transform.position, Quaternion.identity);

		}
		if (col.CompareTag ("Bullet_Blue"))
		{
			Destroy (col.gameObject);
			Instantiate (effectBlue, col.gameObject.transform.position, Quaternion.identity);
		}
		if (col.CompareTag ("Bullet_Red"))
		{
			Destroy (col.gameObject);
			Instantiate (effectRed, col.gameObject.transform.position, Quaternion.identity);
		}
		if (col.CompareTag ("Bullet_Green"))
		{
			Destroy (col.gameObject);
			Instantiate (effectGreen, col.gameObject.transform.position, Quaternion.identity);
		}
		if (col.CompareTag ("Bullet_Yellow"))
		{
			Destroy (col.gameObject);
			Instantiate (effectYellow, col.gameObject.transform.position, Quaternion.identity);
		}


    }
}
