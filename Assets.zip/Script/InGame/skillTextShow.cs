﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;

public class skillTextShow : MonoBehaviour {
    Text t;
    string str = "Skill - 0 Left";
    // Use this for initialization
    void Start () {

        t = GetComponent<Text> ();
    }

    // Update is called once per frame
    void Update () {
        str = string.Format("Skill - {0:0.} Left", varManage.skillLeft);
        t.text = str;
        //t.fontSize = Screen.height * size / 50;
    }
}
