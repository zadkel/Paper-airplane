﻿using UnityEngine;
using System.Collections;

public class Pat_3h_Control : MonoBehaviour {

    public GameObject boss;

    public int phase = 1;

    void Start () {//phase 1
		boss.GetComponent<BossMove1> ().enabled=false;
		boss.GetComponent<BossMove2> ().enabled = false;
		boss.GetComponent<bossMove0> ().enabled = true;

        boss.GetComponent<boss_71h>().enabled=true;
        boss.GetComponent<boss_51h>().enabled=false;
        boss.GetComponent<boss_81h>().enabled=false;
        boss.GetComponent<boss_141h>().enabled=false;
        boss.GetComponent<boss_161h>().enabled=false;
        boss.GetComponent<boss_162h>().enabled=false;
        boss.GetComponent<boss_181h>().enabled=false;
		boss.GetComponent<BossMove1> ().enabled=true;
		boss.GetComponent<BossMove2> ().enabled = false;
    }

    // Update is called once per frame
    void Update () {
        HP_manage.bossPhase = phase;
        if (phase == 1 && HP_manage.bossHPf < 0.8333f)//phase 2
        {
            phase++;
			boss.GetComponent<BossMove1> ().enabled=false;
			boss.GetComponent<BossMove2> ().enabled = false;
			boss.GetComponent<bossMove0> ().enabled = true;

            boss.GetComponent<boss_71h>().enabled=false;
            boss.GetComponent<boss_51h>().enabled=true;
			boss.GetComponent<BossMove1> ().enabled=false;
			boss.GetComponent<BossMove2> ().enabled = true;
        }
        if (phase == 2 && HP_manage.bossHPf < 0.6666f)//phase 3
        {
            phase++;
			boss.GetComponent<BossMove1> ().enabled=false;
			boss.GetComponent<BossMove2> ().enabled = false;
			boss.GetComponent<bossMove0> ().enabled = true;

            boss.GetComponent<boss_51h>().enabled=false;
            boss.GetComponent<boss_81h>().enabled=true;
			boss.GetComponent<BossMove1> ().enabled=true;
			boss.GetComponent<BossMove2> ().enabled = false;
        }
        if (phase == 3 && HP_manage.bossHPf < 0.5f)//phase 4
        {
            phase++;
			boss.GetComponent<BossMove1> ().enabled=false;
			boss.GetComponent<BossMove2> ().enabled = false;
			boss.GetComponent<bossMove0> ().enabled = true;

            boss.GetComponent<boss_81h>().enabled=false;
            boss.GetComponent<boss_141h>().enabled=true;
			boss.GetComponent<BossMove1> ().enabled=false;
			boss.GetComponent<BossMove2> ().enabled = true;
        }
        if (phase == 4 && HP_manage.bossHPf < 0.3333f)//phase 5
        {
            phase++;
			boss.GetComponent<BossMove1> ().enabled=false;
			boss.GetComponent<BossMove2> ().enabled = false;
			boss.GetComponent<bossMove0> ().enabled = true;

            boss.GetComponent<boss_141h>().enabled=false;
            boss.GetComponent<boss_161h>().enabled=true;
            boss.GetComponent<boss_162h>().enabled=true;
			boss.GetComponent<BossMove1> ().enabled=false;
			boss.GetComponent<BossMove2> ().enabled = true;
        }
        if (phase == 5 && HP_manage.bossHPf < 0.1666f)//phase 6
        {
            phase++;
			boss.GetComponent<BossMove1> ().enabled=false;
			boss.GetComponent<BossMove2> ().enabled = false;
			boss.GetComponent<bossMove0> ().enabled = true;

            boss.GetComponent<boss_161h>().enabled=false;
            boss.GetComponent<boss_162h>().enabled=false;
            boss.GetComponent<boss_181h>().enabled=true;
			boss.GetComponent<BossMove1> ().enabled=false;
			boss.GetComponent<BossMove2> ().enabled = false;
        }
        //boss.GetComponent<boss_51h>().enabled=false;
    }
}
