﻿using UnityEngine;
using System.Collections;

public class BossMove2 : MonoBehaviour {
	Vector3 norVec;
	Vector3 traceVec;
	float sp=1;
	float timer=3;
	// Use this for initialization
	void Start () {
		norVec = transform.position + new Vector3 (Random.Range (-1f, 0f), Random.Range (-1f, 1f), 0);

	}
	// Update is called once per frame
	void Update () {
		timer -= Time.deltaTime;
		if (timer < 0) {
			timer = Random.Range (4f, 7f);
			sp = Random.Range (4f, 7f);
			norVec = (transform.position + (new Vector3 (Random.Range (-5f, 5f), Random.Range (-1f, 1f), 0))).normalized * sp;
		}
		traceVec = norVec - transform.position;
		transform.position += traceVec * Time.deltaTime;

		if (transform.position.y < 7) {
			transform.position = new Vector2 (transform.position.x, 7);
		}
		if (transform.position.y > 15) {
			transform.position = new Vector2 (transform.position.x, 15);
		}
		if (transform.position.x > 15) {
			transform.position = new Vector2 (15, transform.position.y);
		}
		if (transform.position.x < -15) {
			transform.position = new Vector2 (-15, transform.position.y);
		}

	}
}
