﻿using UnityEngine;
using System.Collections;

public class Pat_1h_Control : MonoBehaviour {

    public GameObject boss;
    public GameObject pet1;
    public GameObject pet2;

    public int phase = 1;

    void Start () {//phase 1
		boss.GetComponent<BossMove1> ().enabled=false;
		boss.GetComponent<BossMove2> ().enabled = false;
		boss.GetComponent<bossMove0> ().enabled = true;
        boss.GetComponent<boss_101h>().enabled=true;
        boss.GetComponent<boss_22h>().enabled=false;
        boss.GetComponent<boss_41h>().enabled=false;
        boss.GetComponent<boss_151h>().enabled=false;
        boss.GetComponent<boss_111h>().enabled=false;
        boss.GetComponent<boss_121h>().enabled=false;
        pet1.GetComponent<boss_23h>().enabled=false;
        pet2.GetComponent<boss_21h>().enabled=false;
		boss.GetComponent<BossMove1> ().enabled=false;
		boss.GetComponent<BossMove2> ().enabled=true;
    }

    // Update is called once per frame
    void Update () {
        HP_manage.bossPhase = phase;
        if (phase == 1 && HP_manage.bossHPf < 0.8333f)//phase 2
        {
            phase++;
			boss.GetComponent<BossMove1> ().enabled=false;
			boss.GetComponent<BossMove2> ().enabled = false;
			boss.GetComponent<bossMove0> ().enabled = true;

            boss.GetComponent<boss_101h>().enabled=false;
            boss.GetComponent<boss_22h>().enabled=true;
            pet1.GetComponent<boss_23h>().enabled=true;
            pet2.GetComponent<boss_21h>().enabled=true;
			boss.GetComponent<BossMove1> ().enabled=true;
			boss.GetComponent<BossMove2> ().enabled = false;
        }
        if (phase == 2 && HP_manage.bossHPf < 0.6666f)//phase 3
        {
            phase++;
			boss.GetComponent<BossMove1> ().enabled=false;
			boss.GetComponent<BossMove2> ().enabled = false;
			boss.GetComponent<bossMove0> ().enabled = true;

            boss.GetComponent<boss_22h>().enabled=false;
            pet1.GetComponent<boss_23h>().enabled=false;
            pet2.GetComponent<boss_21h>().enabled=false;
            boss.GetComponent<boss_41h>().enabled=true;

        }
        if (phase == 3 && HP_manage.bossHPf < 0.5f)//phase 4
        {
            phase++;
			boss.GetComponent<BossMove1> ().enabled=false;
			boss.GetComponent<BossMove2> ().enabled = false;
			boss.GetComponent<bossMove0> ().enabled = true;

            boss.GetComponent<boss_41h>().enabled=false;
            boss.GetComponent<boss_151h>().enabled=true;
			boss.GetComponent<BossMove1> ().enabled=false;
			boss.GetComponent<BossMove2> ().enabled = true;
        }
        if (phase == 4 && HP_manage.bossHPf < 0.3333f)//phase 5
        {
            phase++;
			boss.GetComponent<BossMove1> ().enabled=false;
			boss.GetComponent<BossMove2> ().enabled = false;
			boss.GetComponent<bossMove0> ().enabled = true;

            boss.GetComponent<boss_151h>().enabled=false;
            boss.GetComponent<boss_111h>().enabled=true;
			boss.GetComponent<BossMove1> ().enabled=false;
			boss.GetComponent<BossMove2> ().enabled = false;
        }
        if (phase == 5 && HP_manage.bossHPf < 0.1666f)//phase 6
        {
            phase++;
			boss.GetComponent<BossMove1> ().enabled=false;
			boss.GetComponent<BossMove2> ().enabled = false;
			boss.GetComponent<bossMove0> ().enabled = true;

            boss.GetComponent<boss_111h>().enabled=false;
            boss.GetComponent<boss_121h>().enabled=true;
			boss.GetComponent<BossMove1> ().enabled=false;
			boss.GetComponent<BossMove2> ().enabled = false;
        }
        //boss.GetComponent<boss_51h>().enabled=false;
    }
}
