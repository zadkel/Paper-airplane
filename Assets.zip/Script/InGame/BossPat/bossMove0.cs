﻿using UnityEngine;
using System.Collections;

public class bossMove0 : MonoBehaviour {
	GameObject Boss;
	Vector3 norVec;
	Vector3 traceVec;
	float sp=1;
	// Use this for initialization
	void Start () {
		norVec = 10*Vector3.up;
	}
		
	// Update is called once per frame
	void Update () {
		traceVec = norVec - transform.position;
		transform.position += traceVec *sp* Time.deltaTime;
		if(Vector3.Distance(norVec,transform.position)<0.1f){
		transform.GetComponent<bossMove0> ().enabled = false;
		}


	}

}
