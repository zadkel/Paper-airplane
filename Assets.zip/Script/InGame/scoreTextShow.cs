﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;
using System.Diagnostics;

public class scoreTextShow : MonoBehaviour {
    Text t;
    public Stopwatch timer;

    string str = "Score - ";
    // Use this for initialization
    void Start () {
        timer = new Stopwatch();
        t = GetComponent<Text> ();
        phaseScore[0]=0;
        phaseScore[1]=0;
        phaseScore[2]=0;
        phaseScore[3]=0;
        phaseScore[4]=0;
        phaseScore[5]=0;
    }

    int phaseTemp = 0;
    int[] phaseScore = new int[6];
    void scoreCul(){
        int scoreVar = 0;
        scoreVar += (HP_manage.bossHPMax - HP_manage.bossHP) * 10;
        scoreVar += (HP_manage.bossPhase - 1)*500000;
        phaseTime();
        scoreVar += phaseScore[0];
        scoreVar += phaseScore[1];
        scoreVar += phaseScore[2];
        scoreVar += phaseScore[3];
        scoreVar += phaseScore[4];
        scoreVar += phaseScore[5];
        varManage.score = scoreVar;
    }
    void phaseTime(){
        float totalSec=0;
        if(phaseTemp==0)
        {
            phaseTemp++;
            timer.Start();
            return;
        }
        if(HP_manage.bossPhase!=phaseTemp)
        {
            timer.Stop();
            totalSec = (float)timer.Elapsed.TotalSeconds;
            timer.Reset();
            phaseScore[phaseTemp - 1] = (int)Mathf.Round(((60f - totalSec)/6f)*10000f) * 10;
            if (phaseScore[phaseTemp - 1] < 0)
                phaseScore[phaseTemp - 1] = 0;
            print(totalSec);
            print(phaseScore[phaseTemp - 1]);

            phaseTemp = HP_manage.bossPhase;
            timer.Start();
        }
    }

    // Update is called once per frame
    void Update () {
        scoreCul();
        str = string.Format("Score - {0:00000000.}", varManage.score);
        t.text = str;

        //t.fontSize = Screen.height * size / 50;
    }
}
