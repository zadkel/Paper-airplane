﻿using UnityEngine;
using System.Collections;

public static class HP_manage{
    public static int bossHPMax = 80000;
    public static int bossHP = bossHPMax;
    public static float bossHPf = 1;

    public static int bossPhase = 0;

    static int bulDamage = varManage.bulletDamage;

    public static void bossDamage()
    {
        bossHP -= bulDamage;
        bossHPf = (float)bossHP / (float)bossHPMax;
    }

}
