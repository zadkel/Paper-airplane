﻿using UnityEngine;
using System.Collections;

public class HP_bar : MonoBehaviour {

	// Update is called once per frame
	void Update () {
        transform.localScale = new Vector3((1.035f * HP_manage.bossHPf),0.896f,1f);
        transform.localPosition = new Vector3((1.035f * HP_manage.bossHPf - 1.035f)/2f, 0f, -1f);
        if (HP_manage.bossHP <= 0)
			transform.localScale = new Vector3(0f,0f,0f);
	}
}