﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;

public class MainScene : MonoBehaviour {

    bool highlightGS = false;
    bool highlightC = false;

    public GameObject highlightGSG;
    public GameObject highlightCG;

    void Start () {
        highlightGS = true;
    }

	void Update () {
        if (highlightGS){highlightGSG.GetComponent<Text>().color = new Color(1, 1, 0, 1);
        }else{highlightGSG.GetComponent<Text>().color = new Color(1, 1, 0, 0.3f);}
        if (highlightC){highlightCG.GetComponent<Text>().color = new Color(1, 1, 0, 1);
        }else{highlightCG.GetComponent<Text>().color = new Color(1, 1, 0, 0.3f);}
        if (Input.GetKeyDown(KeyCode.DownArrow))
        {
            if (highlightGS)
            {
                highlightGS = false;
                highlightC = true;
            }
        }
        if (Input.GetKeyDown(KeyCode.UpArrow))
        {
            if (highlightC)
            {
                highlightC = false;
                highlightGS = true;
            }
        }
        if (Input.GetKeyDown(KeyCode.Z))
        {
            if (highlightGS)
            {
                Scenemov.toHtP();
            }
            if (highlightC)
            {
                Scenemov.toCredit();
            }
        }
	}
}
