﻿using UnityEngine;
using System.Collections;

public class HtpScene : MonoBehaviour {

	// Update is called once per frame
	void Update () {
        if (Input.GetKeyDown(KeyCode.Z))
        {
            Scenemov.toSelect();
        }
	}
}
