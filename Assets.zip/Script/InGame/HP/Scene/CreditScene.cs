﻿using UnityEngine;
using System.Collections;

public class CreditScene : MonoBehaviour {

    // Update is called once per frame
    void Update () {
        if (Input.GetKeyDown(KeyCode.Z))
            Scenemov.toMain();
    }
}
