﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;

public class selectScene : MonoBehaviour {

    int whatSelect = 1;

    bool highlightR = false;
    bool highlightG = false;
    bool highlightBl = false;

    bool highlightA = false;
    bool highlightB = false;
    bool highlightC = false;

    bool highlightNormal = false;
    bool highlightHard = false;

    bool highlightEnter = false;

    public GameObject highlightRG;
    public GameObject highlightGG;
    public GameObject highlightBlG;

    public GameObject highlightAG;
    public GameObject highlightBG;
    public GameObject highlightCG;

    public GameObject highlightNG;
    public GameObject highlightHG;

    public GameObject highlightEG;

	public GameObject highlightRE;
	public GameObject highlightGE;
	public GameObject highlightBE;

    public GameObject Chara;

    public GameObject totalScore;

    public Sprite redSprite;
    public Sprite greenSprite;
    public Sprite blueSprite;
	// Use this for initialization
	void Start () {
        highlightR = true;
        varManage.clear();
        totalScore.GetComponent<Text>().text= string.Format("total Score : {0:00000000.}", varManage.totalScore);
	}
	
	// Update is called once per frame
    void Update () {
        if (highlightR){highlightRG.GetComponent<Text>().color = new Color(1, 1, 1, 1);
        }else{highlightRG.GetComponent<Text>().color = new Color(1, 1, 1, 0.3f);}
        if (highlightG){highlightGG.GetComponent<Text>().color = new Color(1, 1, 1, 1);
        }else{highlightGG.GetComponent<Text>().color = new Color(1, 1, 1, 0.3f);}
        if (highlightBl){highlightBlG.GetComponent<Text>().color = new Color(1, 1, 1, 1);
        }else{highlightBlG.GetComponent<Text>().color = new Color(1, 1, 1, 0.3f);}

        if (highlightA){highlightAG.GetComponent<Text>().color = new Color(1, 1, 1, 1);
        }else{highlightAG.GetComponent<Text>().color = new Color(1, 1, 1, 0.3f);}
        if (highlightB){highlightBG.GetComponent<Text>().color = new Color(1, 1, 1, 1);
        }else{highlightBG.GetComponent<Text>().color = new Color(1, 1, 1, 0.3f);}
        if (highlightC){highlightCG.GetComponent<Text>().color = new Color(1, 1, 1, 1);
        }else{highlightCG.GetComponent<Text>().color = new Color(1, 1, 1, 0.3f);}

        if (highlightNormal){highlightNG.GetComponent<Text>().color = new Color(1, 1, 1, 1);
        }else{highlightNG.GetComponent<Text>().color = new Color(1, 1, 1, 0.3f);}
        if (highlightHard){highlightHG.GetComponent<Text>().color = new Color(1, 1, 1, 1);
        }else{highlightHG.GetComponent<Text>().color = new Color(1, 1, 1, 0.3f);}

        if (highlightEnter){highlightEG.GetComponent<Text>().color = new Color(1, 1, 1, 1);
        }else{highlightEG.GetComponent<Text>().color = new Color(1, 1, 1, 0.2f);}
            
        if (highlightR)
        {
            Chara.GetComponent<SpriteRenderer>().sprite = redSprite;
        }
        if (highlightG)
        {
            Chara.GetComponent<SpriteRenderer>().sprite = greenSprite;
        }
        if (highlightBl)
        {
            Chara.GetComponent<SpriteRenderer>().sprite = blueSprite;
        }

        if (Input.GetKeyDown(KeyCode.LeftArrow))
        {
            if (whatSelect == 1)
            {
                if (highlightG)
                {
                    highlightG = false;
                    highlightR = true;
                }
                if (highlightBl)
                {
                    highlightBl = false;
                    highlightG = true;
                }
            }
            if (whatSelect == 2)
            {
                if (highlightB)
                {
                    highlightC = false;
                    highlightB = false;
                    highlightA = true;
                }
                if (highlightC)
                {
                    highlightC = false;
                    highlightB = true;
                    highlightA = false;
                }
            }
            if (whatSelect == 3)
            {
                if (highlightHard)
                {
                    highlightHard = false;
                    highlightNormal = true;
                }
            }
        }
        if (Input.GetKeyDown(KeyCode.RightArrow))
        {
            if (whatSelect == 1)
            {
                if (highlightR)
                {
                    highlightR = false;
                    highlightG = true;
                }
                else if (highlightG)
                {
                    highlightG = false;
                    highlightBl = true;
                }
            }
            if (whatSelect == 2)
            {
                if (highlightA)
                {
                    highlightA = false;
                    highlightB = true;
                    highlightC = false;
                }
                else if (highlightB)
                {
                    highlightA = false;
                    highlightB = false;
                    highlightC = true;
                }
            }
            if (whatSelect == 3)
            {
                if (highlightNormal)
                {
                    highlightNormal = false;
                    highlightHard = true;
                }
            }
        }
        if (Input.GetKeyDown(KeyCode.Z))
        {
            if(whatSelect!=4)
                whatSelect++;
            if (whatSelect == 2)
            {
                highlightA = true;
            }
            if (whatSelect == 3)
            {
                highlightNormal = true;
            }
            if (whatSelect == 4)
            {
                highlightEnter = true;
            }
        }
        if (Input.GetKeyDown(KeyCode.X))
        {
            if(whatSelect!=1)
                whatSelect--;
            if (whatSelect == 1)
            {
                highlightA = false;
                highlightB = false;
                highlightC = false;
            }
            if (whatSelect == 2)
            {
                highlightNormal = false;
                highlightHard = false;
            }
            if (whatSelect == 3)
            {
                highlightEnter = false;
            }
        }
		if (Input.GetKeyDown (KeyCode.P)) {
			varManage.totalScore = 0;
		}

		if (highlightR){highlightRE.GetComponent<Text>().color = new Color(1, 1, 1, 1);
		}else{highlightRE.GetComponent<Text>().color = new Color(1, 1, 1, 0);}
		if (highlightG){highlightGE.GetComponent<Text>().color = new Color(1, 1, 1, 1);
		}else{highlightGE.GetComponent<Text>().color = new Color(1, 1, 1, 0);}
		if (highlightBl){highlightBE.GetComponent<Text>().color = new Color(1, 1, 1, 1);
		}else{highlightBE.GetComponent<Text>().color = new Color(1, 1, 1, 0);}

        if (Input.GetKeyDown(KeyCode.Return))
        {
            if (highlightEnter)
            {
                varManage.clear();
                /************************************/
                if (highlightR)
                {
                    varManage.player = 1;
                }
                if (highlightG)
                {
                    varManage.player = 2;
                }
                if (highlightBl)
                {
                    varManage.player = 3;
                }
                /************************************/
                if (highlightNormal)
                {
                    Difficulty.identity = "Normal";
                    varManage.skillLeft = 3;
                }
                if (highlightHard)
                {
                    Difficulty.identity = "Hard";
                    varManage.skillLeft = 1;
                }
                /************************************/
                if (highlightA)
                {
                    Scenemov.to1h();
                }
                if (highlightB)
                {
                    Scenemov.to2h();
                }
                if (highlightC)
                {
                Scenemov.to3h();
                }
            }
        }

	}
}
