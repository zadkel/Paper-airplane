﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class scoreScene : MonoBehaviour {
    public Text t1;
    public Text t2;
    public Text t3;
    string str = "Score - ";

    int nhb;

    void Start () {
		str = string.Format("In-game Score - {0:00000000.}", varManage.score);
		t1.text = str;
		nhb = (500 - (varManage.death)) * 10000;
		if (nhb < 0)
			nhb = 0;
		str = string.Format("No-Hit Bonus - {0:00000000.}",nhb);
		varManage.score += nhb;
		t2.text = str;
		str = string.Format("Final Score - {0:00000000.}", varManage.score);
		t3.text = str;


    }
    // Update is called once per frame
    void Update () {
        //scoreScene


        //go to select
        if (Input.GetKeyDown(KeyCode.Z))
        {
            varManage.totalScore += varManage.score;
            Scenemov.toSelect();

        }
    }
}
