﻿using UnityEngine;
using System.Collections;

public class bossWave : MonoBehaviour {
	float scale;
	// Use this for initialization
	void Start () {

	}
	
	// Update is called once per frame
	void Update () {
		scale = transform.localScale.x;
		transform.localScale += (Vector3.up + Vector3.right) * 200* Time.deltaTime;

		if (scale >100) {
			Destroy (gameObject);
		}


	}
}
