﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;
using System.Diagnostics;

public class playTTextShow : MonoBehaviour {
    public Stopwatch timer;
    float delay = 0f;
    Text t;
    string str = "Play time - 00 : 00";
    // Use this for initialization
    void Start () {
        timer = new Stopwatch();
        timer.Start();
        t = GetComponent<Text> ();
    }

    // Update is called once per frame
    void Update () {
        str = string.Format("Play time - {0:00.} : {1:00.}", timer.Elapsed.Minutes, timer.Elapsed.Seconds);
        t.text = str;
        if(HP_manage.bossHP<=0)
        {
            timer.Stop();
            HP_manage.bossPhase = 7;
            delay+=Time.deltaTime;
            if (delay >= 10f)
                Scenemov.toScoreShow();
        }
        //t.fontSize = Screen.height * size / 50;
    }
}
