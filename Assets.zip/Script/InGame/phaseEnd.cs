﻿using UnityEngine;
using System.Collections;

public class phaseEnd : MonoBehaviour {

    public GameObject panel;
    GameObject obj;

	// Use this for initialization
	void Start () {
	
	}
    float timer = 0.1f;
    int phaseTemp = 1;
    bool active = false;
    void phaseChange(){
        if(phaseTemp==0)
        {
            phaseTemp++;
            return;
        }
        if (timer < 0 && active)
        {
            timer = 0.2f;
            active = false;
            Destroy(obj);
        }
        if (active)
        {
            timer -= Time.deltaTime;
        }
        if((HP_manage.bossPhase!=phaseTemp || HP_manage.bossHP<=0)&& !active )
        {
            obj = Instantiate(panel, new Vector2(0, 0), new Quaternion()) as GameObject;
            active = true;
            print("aaaaaaa");
            phaseTemp = HP_manage.bossPhase;
        }
    }

	// Update is called once per frame
	void Update () {
        phaseChange();
	}
}
