﻿using UnityEngine;
using System.Collections;

public class bullet : MonoBehaviour {
	float sp=50;
	int i;
	float degree;
	int shot;
	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		transform.Translate (0, sp * Time.deltaTime * 2, 0);

		if (transform.position.y > 25) {
			Destroy (this.gameObject);
		}




	}
}
