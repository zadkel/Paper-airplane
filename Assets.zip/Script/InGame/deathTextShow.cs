﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;

public class deathTextShow : MonoBehaviour {
    Text t;
    string str = "Hit - 000";
    // Use this for initialization
    void Start () {

        t = GetComponent<Text> ();
    }

    // Update is called once per frame
    void Update () {
        str = string.Format("Hit - {0:000.}", varManage.death);
        t.text = str;
        //t.fontSize = Screen.height * size / 50;
    }
}
