﻿using UnityEngine;
using System.Collections;

public class crtDeath : MonoBehaviour {
	public GameObject effectBlue;
	public GameObject effectRed;
	public GameObject effectGreen;
	public GameObject effectYellow;

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
		
	}

    void OnTriggerEnter2D(Collider2D col)
    {

		if (col.CompareTag ("Bullet_UnBroken")) {
			varManage.death++;
			Instantiate (effectBlue, transform.position, Quaternion.identity);

		}
		if (col.CompareTag ("Bullet_Blue"))
		{
			varManage.death++;
			Destroy (col.gameObject);
			Instantiate (effectBlue, col.gameObject.transform.position, Quaternion.identity);
		}
		if (col.CompareTag ("Bullet_Red"))
		{
			varManage.death++;
			Destroy (col.gameObject);
			Instantiate (effectRed, col.gameObject.transform.position, Quaternion.identity);
		}
		if (col.CompareTag ("Bullet_Green"))
		{
			varManage.death++;
			Destroy (col.gameObject);
			Instantiate (effectGreen, col.gameObject.transform.position, Quaternion.identity);
		}
		if (col.CompareTag ("Bullet_Yellow"))
		{
			varManage.death++;
			Destroy (col.gameObject);
			Instantiate (effectYellow, col.gameObject.transform.position, Quaternion.identity);
		}



    }
}
