﻿using UnityEngine;
using System.Collections;

public class tPosition:MonoBehaviour{
	public static float tx;
	public static float ty;
	public static Vector3 tVec;
}

public class Number : MonoBehaviour{
    public static int Sequence=0;
    public static int Sequence11=0;
}



public class crtMove : MonoBehaviour {
	public Sprite redSpriteM;
	public Sprite redSpriteL;
	public Sprite redSpriteR;
	public Sprite greenSpriteM;
	public Sprite greenSpriteL;
	public Sprite greenSpriteR;
	public Sprite blueSpriteM;
	public Sprite blueSpriteL;
	public Sprite blueSpriteR;

	public Sprite gameSpriteM;
	public Sprite gameSpriteL;
	public Sprite gameSpriteR;


	public GameObject shootObj;
	public float sp=varManage.playerSpd;
	int j;
	// Use this for initialization
    void Start () {
        this.GetComponent<RedSkill>().enabled = false;
        this.GetComponent<BlueSkill>().enabled = false;
        this.GetComponent<GreenSkill>().enabled = false;
        if (varManage.player == 1)
		{
			gameSpriteM=redSpriteM;
			gameSpriteL=redSpriteL;
            gameSpriteR=redSpriteR;
            this.GetComponent<RedSkill>().enabled = true;
        }
        if (varManage.player == 2)
		{
			gameSpriteM=greenSpriteM;
			gameSpriteL=greenSpriteL;
            gameSpriteR=greenSpriteR;
            this.GetComponent<GreenSkill>().enabled = true;
        }
        if (varManage.player == 3)
		{
			gameSpriteM=blueSpriteM;
			gameSpriteL=blueSpriteL;
            gameSpriteR=blueSpriteR;
            this.GetComponent<BlueSkill>().enabled = true;
        }

	}
	
	// Update is called once per frame
	void Update () {

		tPosition.tx = transform.position.x;
		tPosition.ty = transform.position.y;
		tPosition.tVec = transform.position;
		//유도하기 위한 좌표 값을 매 프레임 마다 저장


		if (Input.GetKey (KeyCode.LeftShift)) {
            sp = varManage.playerSpd/2;
		} else {
            sp = varManage.playerSpd;
		}
			
		if (Input.GetKey (KeyCode.UpArrow )) {
			transform.Translate (0, sp * Time.deltaTime, 0);
		} else if (Input.GetKey (KeyCode.DownArrow )) {
			transform.Translate (0, -sp * Time.deltaTime, 0);
		}

		GetComponent<SpriteRenderer> ().sprite = gameSpriteM;
		if (Input.GetKey (KeyCode.RightArrow)) {
			transform.Translate (sp * Time.deltaTime, 0, 0);
			GetComponent<SpriteRenderer> ().sprite = gameSpriteR;
		} else if (Input.GetKey (KeyCode.LeftArrow)) {
			transform.Translate (-sp * Time.deltaTime, 0, 0);
			GetComponent<SpriteRenderer> ().sprite = gameSpriteL;
		}

			
		if (Input.GetKey (KeyCode.Z )) {
			for (j = 0; j < 2; j++) {
				Instantiate (shootObj, new Vector3 (transform.position.x+Mathf.Cos(Mathf.PI*j), transform.position.y+2, 2), Quaternion.identity);
			}
		}


		if (transform.position.x > 20) {
			transform.position = new Vector2 (20, transform.position.y);
		}
		if (transform.position.x < -20) {
			transform.position = new Vector2 (-20, transform.position.y);
		}
		if (transform.position.y > 20) {
			transform.position = new Vector2 (transform.position.x, 20);
		}
		if (transform.position.y < -20) {
			transform.position = new Vector2 (transform.position.x, -20);
		}




	}
}
