﻿using UnityEngine;
using System.Collections;

public class toMainF5 : MonoBehaviour {

	// Update is called once per frame
	void Update () {
        if (Input.GetKeyDown(KeyCode.F5))
            Scenemov.toMain();
	}
}
