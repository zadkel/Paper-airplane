﻿using UnityEngine;
using System.Collections;

public class test : MonoBehaviour {

	public GameObject boss;

    int phase = 1;
    void Start () {
        boss.GetComponent<boss_51h>().enabled = true;
    }
	// Update is called once per frame
	void Update () {
        if (phase == 1 && HP_manage.bossHPf < 0.5)
        {
            boss.GetComponent<boss_51h>().enabled = false;
            boss.GetComponent<boss_41h>().enabled = true;
        }
		//boss.GetComponent<boss_51h>().enabled=false;
	}
}
